import 'package:flutter/material.dart';

class Count extends StatelessWidget {
  final int? count;
  final Function? onCountSelected;
  final Function(int)? onCountChange;

  Count({this.count, this.onCountSelected, this.onCountChange});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        IconButton(
          icon: Icon(Icons.add),
          onPressed: () {
            onCountChange!(1);
          },
        ),
        TextButton(
          style: ButtonStyle(
            backgroundColor: MaterialStateProperty.all<Color>(Colors.blue),
          ),
          onPressed: () => {
            onCountSelected!(),
          },
          child: Text(
            'Count = $count',
            style: TextStyle(
              color: Colors.white,
              fontSize: 20,
            ),
          ),
        ),
        IconButton(
          icon: Icon(Icons.remove),
          onPressed: () {
            onCountChange!(-1);
          },
        ),
      ],
    );
  }
}
