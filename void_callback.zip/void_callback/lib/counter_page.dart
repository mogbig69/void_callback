import 'package:flutter/material.dart';
import 'package:void_callback/count.dart';

class CounterPage extends StatefulWidget {
  const CounterPage({Key? key, required this.title}) : super(key: key);
  final String title;
  @override
  State<CounterPage> createState() => _CounterPageState();
}

class _CounterPageState extends State<CounterPage> {
  int count = 0;
  var myInt;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body: Center(
        child: Count(
          count: count,
          onCountChange: (myInt) {
            setState(() {
              count += myInt;
            });
          },
          onCountSelected: () {
            print('Selected the counter!');
          },
        ),
      ),
    );
  }
}
