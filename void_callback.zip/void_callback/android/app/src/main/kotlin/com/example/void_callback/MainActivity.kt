package com.example.void_callback

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
